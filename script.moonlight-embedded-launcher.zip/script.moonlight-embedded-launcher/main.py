# -*- coding: utf-8 -*-

import os
os.system("systemd-run ~/.kodi/addons/script.moonlight-embedded-launcher/bin/launch_moonlight.sh")
